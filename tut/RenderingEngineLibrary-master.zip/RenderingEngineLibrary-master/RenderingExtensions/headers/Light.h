#pragma once

namespace renderlib {

class Light {

};

}