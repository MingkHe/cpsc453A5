// RenderingEngine.cpp : Defines the entry point for the console application.
//
#include "GLWindow.h"


int main()
{
	WindowManager wm;
	wm.mainLoop();
}

